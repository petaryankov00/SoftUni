﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    interface IDrawable
    {
        public void Draw();
    }
}
