﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=MPC-1\SQLEXPRESS;Database=SoftJail;User Id=sa;Password=1916";
    }
}
