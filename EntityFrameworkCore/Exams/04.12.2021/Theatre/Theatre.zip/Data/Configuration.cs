﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=MPC-1\SQLEXPRESS;Database=Theatre;User Id=sa;Password=1916";
    }
}
